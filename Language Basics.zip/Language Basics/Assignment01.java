import java.io.*;
public class Assignment01 {

	public static void main(String[] args) {
		
		System.out.println(args[0]+" "+"Technolgies"+" "+args[1]);
	}

}
